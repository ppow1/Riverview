import argparse
import os
import subprocess
import sys
import threading
import time
from pathlib import Path


def pump_stream(source, destinations, stop_event):
    try:
        while not stop_event.is_set():
            chunk = source.read(65536)
            if not chunk:
                break

            dead = []

            for name, pipe in destinations.items():
                try:
                    pipe.write(chunk)
                    pipe.flush()
                except (BrokenPipeError, OSError):
                    dead.append(name)

            for name in dead:
                destinations.pop(name, None)

            if not destinations:
                break
    finally:
        stop_event.set()


def drain_stderr(name, stream, stop_event):
    for raw in iter(stream.readline, b""):
        if stop_event.is_set():
            break

        text = raw.decode(errors="replace").rstrip()

        if text:
            print(f"[{name}] {text}", file=sys.stderr, flush=True)


def main():
    parser = argparse.ArgumentParser(
        description="Single-owner video1 MJPEG relay for human and machine observation."
    )

    parser.add_argument("--video-host", default="video1")
    parser.add_argument("--snapshot", required=True)
    parser.add_argument("--ffplay", required=True)
    parser.add_argument("--ffmpeg", required=True)

    args = parser.parse_args()

    snapshot = Path(args.snapshot)
    snapshot.parent.mkdir(parents=True, exist_ok=True)

    stop_event = threading.Event()

    remote_capture = (
        'ffmpeg -hide_banner -loglevel error '
        '-f v4l2 -input_format mjpeg '
        '-video_size 1920x1080 -framerate 30 '
        '-i /dev/video0 -an -c:v copy -f mjpeg -'
    )

    ssh = subprocess.Popen(
        ["ssh", args.video_host, remote_capture],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        bufsize=0,
    )

    viewer = subprocess.Popen(
        [
            args.ffplay,
            "-hide_banner",
            "-loglevel", "warning",
            "-fflags", "nobuffer",
            "-flags", "low_delay",
            "-framedrop",
            "-f", "mjpeg",
            "-i", "-"
        ],
        stdin=subprocess.PIPE,
        stderr=subprocess.PIPE,
        bufsize=0,
    )

    # This decoder receives the SAME MJPEG byte stream as FFplay.
    # It continuously replaces latest.jpg with a current decoded frame.
    decoder = subprocess.Popen(
        [
            args.ffmpeg,
            "-hide_banner",
            "-loglevel", "error",
            "-f", "mjpeg",
            "-i", "-",
            "-vf", "fps=1",
            "-update", "1",
            "-y",
            str(snapshot),
        ],
        stdin=subprocess.PIPE,
        stderr=subprocess.PIPE,
        bufsize=0,
    )

    threads = [
        threading.Thread(
            target=drain_stderr,
            args=("ssh", ssh.stderr, stop_event),
            daemon=True,
        ),
        threading.Thread(
            target=drain_stderr,
            args=("ffplay", viewer.stderr, stop_event),
            daemon=True,
        ),
        threading.Thread(
            target=drain_stderr,
            args=("snapshot", decoder.stderr, stop_event),
            daemon=True,
        ),
    ]

    for thread in threads:
        thread.start()

    print(f"VIDEO_HOST={args.video_host}", flush=True)
    print(f"SNAPSHOT={snapshot}", flush=True)
    print("RELAY_STATE=RUNNING", flush=True)

    try:
        pump_stream(
            ssh.stdout,
            {
                "viewer": viewer.stdin,
                "snapshot": decoder.stdin,
            },
            stop_event,
        )
    except KeyboardInterrupt:
        stop_event.set()
    finally:
        stop_event.set()

        for proc in (viewer, decoder, ssh):
            try:
                proc.terminate()
            except Exception:
                pass

        for proc in (viewer, decoder, ssh):
            try:
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
