"""Production composition of the accepted Grace HOME cognition seams."""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from typing import Any
from uuid import UUID, uuid4

from riverview.reasoning.binding import BindingConfigurationLoader, CognitionBindingAdapter
from riverview.reasoning.contracts import ReasoningRequest, ReasoningResponse
from riverview.reasoning.home_cognition import AuthorizedHomeProvider, HomeCognitionExecutionError, HomeCognitionInvocation, HomeCognitionService
from riverview.reasoning.cognition_contracts import CognitionTier
from riverview.reasoning.grace_state import GRACE_AUTHORITY_REF, GRACE_OCCUPANT_ID, PostgresAuthoritativeGraceStateSource
from riverview.reasoning.llama_cpp import LlamaCppReasoningAdapter
from riverview.residents.persistence import ResidentContinuityStore
from riverview.reasoning.escalation_policy import ConsequenceClass, POLICY_VERSION
from riverview.river.store import EventStore


class _MeasuredLocalCatalog:
    def __init__(self, provider_id: str, model: str, provider_type: str, resource_ref: str) -> None:
        self.provider_id = provider_id
        self.model = model
        self.provider_type = provider_type
        self.resource_ref = resource_ref

    def available_for(self, *, request_classification: str, required_capability: str, max_age_seconds: int = 300) -> Sequence[Mapping[str, object]]:
        return ({
            "participant_id": self.resource_ref,
            "provider_id": self.provider_id,
            "provider_type": self.provider_type,
            "role": "advisory",
            "capability_name": required_capability,
            "health": "healthy",
            "capacity": 1,
            "contract_version": f"{self.provider_type}-reasoning-envelope-v1",
            "eligible_classifications": (request_classification,),
        },)


def build_grace_home_cognition(
    provider: Callable[[str, ReasoningRequest], ReasoningResponse] | None = None,
    model: str | None = None,
) -> HomeCognitionService:
    implementation = ResidentContinuityStore().active_implementation_binding(GRACE_OCCUPANT_ID)

    provider_ref = str(implementation["provider_ref"])
    model_ref = str(implementation["model_ref"])
    host_ref = str(implementation.get("host_ref") or "local")
    device_ref = str(implementation.get("device_ref") or "unknown")
    configuration_ref = str(implementation.get("configuration_ref") or "")

    selected_provider = provider

    if provider_ref == "llama_cpp":
        selected_provider = LlamaCppReasoningAdapter(
            endpoint=configuration_ref,
            allow_private_lan=True,
        ).chat_complete

    if selected_provider is None:
        raise HomeCognitionExecutionError(
            "provider-unavailable",
            f"Grace HOME provider {provider_ref!r} has no configured reasoning adapter.",
        )

    provider_id = f"{provider_ref}:{model_ref}"
    resource_ref = f"{host_ref}:{device_ref}"

    configuration = BindingConfigurationLoader.from_mapping({
        CognitionTier.HOME_COGNITION.value: {
            "capability_name": "HOME_COGNITION",
            "policy_ref": POLICY_VERSION,
            "configuration_ref": configuration_ref,
            "resource_class_ref": resource_ref,
        }
    })

    authorized = AuthorizedHomeProvider(
        provider_id=provider_id,
        authorization_ref="resident-implementation-policy:v1",
        generate=lambda request: selected_provider(model_ref, request),
    )

    service = HomeCognitionService(
        grace_resident_id=GRACE_OCCUPANT_ID,
        state_source=PostgresAuthoritativeGraceStateSource(),
        event_store=EventStore(),
        binding_adapter=CognitionBindingAdapter(
            _MeasuredLocalCatalog(
                provider_id,
                model_ref,
                provider_ref,
                resource_ref,
            ),
            configuration,
        ),
        provider=authorized,
    )

    service.speech_provider = selected_provider
    service.speech_model = model_ref
    return service


def invocation_for_message(*, instruction: str, correlation_id: UUID, classification: str, prior_history: tuple[str, ...] = ()) -> HomeCognitionInvocation:
    return HomeCognitionInvocation(
        objective_id=uuid4(),
        source_cognition_event_id=uuid4(),
        correlation_id=correlation_id,
        request_class="operator-grace-conversation",
        objective="Provide bounded operational judgment for the current Riverview conversation.",
        question=instruction,
        consequence=ConsequenceClass.DIFFICULT,
        classification=classification,
        expires_at=__import__("datetime").datetime.now(__import__("datetime").UTC).replace(microsecond=0) + __import__("datetime").timedelta(minutes=5),
        authorization_ref="resident-implementation-policy:v1",
        home_belief=False,
        home_belief_reason="The bounded Director of Operations conversation is admitted to HOME cognition without requesting a stronger tier.",
        constraints=("advisory only", "no execution", "no authority expansion", "preserve evidence/assumption distinction"),
        conversation_context=prior_history,
    )


