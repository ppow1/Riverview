import csv
import json
import subprocess
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

OCTO2 = "octo2"
API = "http://192.168.1.162:8080/v1/models"

ROOT = Path(r"T:\OctoMiner_BIOS_Campaign")
DATA = ROOT / "workspace" / "campaign-runtime"
DATA.mkdir(parents=True, exist_ok=True)

CURRENT = DATA / "octo2-current.json"
EVENTS = DATA / "events.jsonl"
TELEMETRY = DATA / "octo2-telemetry.csv"

INTERVAL = 10


def now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def ssh(command):
    try:
        p = subprocess.run(
            ["ssh", "-o", "ConnectTimeout=3", OCTO2, command],
            capture_output=True,
            text=True,
            timeout=6,
        )
        if p.returncode == 0:
            return p.stdout.strip()
    except Exception:
        pass
    return None


def api_ready():
    try:
        with urllib.request.urlopen(API, timeout=3) as r:
            data = json.loads(r.read())
            return r.status == 200 and bool(data.get("data") or data.get("models"))
    except Exception:
        return False


def event(kind, **fields):
    record = {"timestamp": now(), "event": kind, **fields}
    with EVENTS.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def sample():
    raw = ssh(
        'cat /proc/sys/kernel/random/boot_id; '
        'cat /proc/uptime; '
        'pgrep -f "llama-server.*Qwen3-Next-80B" | head -1'
    )

    if raw is None:
        return {
            "timestamp": now(),
            "ssh": False,
            "boot_id": "",
            "uptime_sec": "",
            "llama_pid": "",
            "api_ready": False,
            "state": "OCTO2_UNREACHABLE",
        }

    lines = raw.splitlines()

    boot = lines[0].strip() if len(lines) > 0 else ""
    uptime = lines[1].split()[0] if len(lines) > 1 else ""
    pid = lines[2].strip() if len(lines) > 2 else ""

    ready = api_ready()

    if not pid:
        state = "80B_PROCESS_DOWN"
    elif not ready:
        state = "80B_NOT_READY"
    else:
        state = "80B_READY"

    return {
        "timestamp": now(),
        "ssh": True,
        "boot_id": boot,
        "uptime_sec": uptime,
        "llama_pid": pid,
        "api_ready": ready,
        "state": state,
    }


previous = None

if not TELEMETRY.exists():
    with TELEMETRY.open("w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([
            "timestamp",
            "ssh",
            "boot_id",
            "uptime_sec",
            "llama_pid",
            "api_ready",
            "state",
        ])

print("Octo2 campaign health monitor")
print(f"Interval: {INTERVAL} seconds")
print(f"Runtime:  {DATA}")
print("Ctrl+C stops monitor")
print()

while True:
    current = sample()

    CURRENT.write_text(
        json.dumps(current, indent=2),
        encoding="utf-8",
    )

    with TELEMETRY.open("a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([
            current["timestamp"],
            current["ssh"],
            current["boot_id"],
            current["uptime_sec"],
            current["llama_pid"],
            current["api_ready"],
            current["state"],
        ])

    if previous is None:
        event(
            "octo2_monitor_started",
            state=current["state"],
            boot_id=current["boot_id"],
        )
    else:
        if (
            current["boot_id"]
            and previous["boot_id"]
            and current["boot_id"] != previous["boot_id"]
        ):
            event(
                "octo2_boot_changed",
                old_boot_id=previous["boot_id"],
                new_boot_id=current["boot_id"],
            )

        if current["state"] != previous["state"]:
            event(
                "octo2_state_changed",
                old_state=previous["state"],
                new_state=current["state"],
            )

    print(
        f'{current["timestamp"]}  '
        f'{current["state"]:<20} '
        f'uptime={current["uptime_sec"]:<10} '
        f'pid={current["llama_pid"]:<7} '
        f'boot={current["boot_id"]}'
    )

    previous = current
    time.sleep(INTERVAL)
