# SNAIL v1.0 — CODEX PRODUCTION BUILD SPECIFICATION
## Steward Not Always In Loop

## 1. MANDATE
Build and deliver SNAIL v1.0 as a production-ready, persistent, evidence-driven engineering campaign runtime integrated with the existing OctoMiner Steward infrastructure in this packet.

Codex is the software engineer that builds SNAIL. Codex is NOT part of normal SNAIL runtime. After implementation and qualification, SNAIL runs without Codex.

Do not deliver a prototype, scaffold, TODO collection, mock dashboard, placeholder adapters, or architecture-only result. Deliver a functioning subsystem plus tests and operating instructions.

## 2. INPUT SCOPE — IMPORTANT
This packet is intentionally curated. DO NOT perform repository-wide Riverview or Riverview Standalone discovery. The source archive from which this packet was derived contains tens of thousands of files and large unrelated runtime/history areas.

Start with BUILD_PACKET_MANIFEST.md, then CURRENT_STEWARD_SNAPSHOT, then the canonical campaign documents under REFERENCE_RIVERVIEW/docs/operations/octominer/campaign.

If implementation exposes a missing dependency, identify the exact dependency and why it is needed. Do not recursively explore all Riverview as a substitute for bounded dependency resolution.

## 3. CURRENT IMPLEMENTATION AUTHORITY
CURRENT_STEWARD_SNAPSHOT is the best supplied representation of the live OctoMiner BIOS Steward implementation and runtime evidence as of 2026-10-04 18:26 local campaign time. Treat its dashboard/controller/runtime artifacts as the primary implementation baseline.

REFERENCE_RIVERVIEW contains selected broader source and durable engineering knowledge. Reuse useful components, but do not let older/general Riverview architecture override the current campaign implementation silently.

## 4. RECONCILE THE BIOS FREEZE POINT
Create docs/operations/octominer/campaign/SNAIL_HANDOFF_2026-10-04.md in the delivered implementation. Preserve historical files. Update/augment current-state documentation so the latest authoritative state points to this handoff.

The handoff must establish from supplied evidence: infrastructure qualification is complete; independent Octo1 video observation and PiKVM HID have been proven; DEV/3060 Ti vision exists but BIOS-grade transcription is not yet authoritative; Octo2/80B monitoring and recovery states exist; actual SNAIL-controlled BIOS candidate mutation has not begun; Octo1 physical reset/power remains human-dependent unless supplied evidence proves otherwise.

Candidate C0 is the currently booting baseline unless supplied evidence establishes a later baseline. SNAIL v1 qualification stops before autonomous C1 mutation.

## 5. RUNTIME ARCHITECTURE
DEV MACHINE: persistent SNAIL controller, Steward UI, state, checkpoints, events, evidence, validator, execution coordination, Octo2 monitoring, vision interface and snapshots.

OCTO2: Qwen3-Next-80B-A3B-Instruct-Q4_K_M is the primary engineering reasoning worker. Treat it as stateless, intermittent and replaceable.

DEV RTX 3060 Ti: vision worker/service used to make the 80B effectively vision-enabled. It is not the primary engineering reasoning authority.

PiKVM: Octo1 HID/control path.

video1: independent physical observation path for Octo1.

OCTO1: BIOS campaign target.

## 6. FUNDAMENTAL RULE
SNAIL RESUMES FROM EVIDENCE AND PERSISTENT STATE, NEVER FROM AI CHAT MEMORY.

Assume the 80B worker can disappear after any response. Anything needed for the next decision must be durable on DEV. A fresh worker process must continue correctly from disk-backed state/evidence.

## 7. EVENT LOOP
Implement explicit stages:
OBSERVE -> SELECT EVIDENCE -> BUILD REASONING PACKET -> REASON -> PROPOSE -> VALIDATE -> EXECUTE -> OBSERVE EFFECT -> CAPTURE EVIDENCE -> VERIFY -> APPEND EVENT -> CHECKPOINT -> CONTINUE.

A command being sent is not proof of success. Verify effects independently whenever practical.

## 8. STATE
Persist explicit states including STARTING, PREFLIGHT, READY, OBSERVING, REASONING, VALIDATING, EXECUTING, VERIFYING, WAITING_FOR_WORKER, WAITING_FOR_STEWARD, PAUSING, PAUSED, RECOVERING, STOPPING, STOPPED, ABORTING and ERROR.

Persist campaign/phase/test/event identifiers, objective, task, Steward direction, hypothesis, worker state/boot ID/PID, pending reasoning/execution operations, evidence references, last verified machine state, pause/recovery state and checkpoint time.

## 9. EVIDENCE MODEL
Maintain distinct epistemic classes: OBSERVED (direct evidence), DERIVED (conclusion tied to evidence IDs), HYPOTHESIS (unproven model explanation). Repetition by a model never promotes a hypothesis to fact.

## 10. APPEND-ONLY FLIGHT RECORDER
Use/extend the existing append-only campaign event mechanism. Significant events need IDs, timestamps, actor/type, state before/after, inputs/evidence, action/result, worker identity where relevant, duration and status. Corrections are new events; do not rewrite history.

## 11. 80B REASONING PACKETS
Codex may inspect this curated packet broadly while building. During runtime, however, the 80B worker must receive bounded, auditable reasoning packets rather than the whole codebase/history. Include only relevant objective/task/state, hard constraints, Steward direction, proven facts/failures, relevant lessons/events/evidence, current hypothesis and pending decision.

Require structured output: interpretation, evidence_used, hypothesis, proposed_action, expected_result, pass_condition, fail_condition, timeout, confidence, escalation_required. Reject malformed responses rather than guessing intent.

## 12. OCTO2 REBOOT SURVIVAL
Reuse existing Octo2 monitoring. Do not build a redundant reboot monitor and do not solve reboot root cause in v1.

A transient OCTO2_UNREACHABLE without boot-ID change is not automatically a reboot. Boot-ID change is authoritative reboot evidence.

On worker loss: persist pending transaction/evidence; checkpoint; enter WAITING_FOR_WORKER; keep monitoring on DEV; wait for real 80B_READY; build a fresh reasoning packet from disk; resume without duplicating already-verified state-changing actions.

## 13. VISION AND LIVE FRAME
Preserve original frames and vision interpretations separately. Decision-relevant mutable latest.jpg frames must be copied to immutable evidence IDs/files before being relied upon.

Expose the current Octo1 latest frame in the Steward dashboard (panel/tab is acceptable) with capture timestamp, age, source, resolution, vision interpretation/confidence where available and evidence ID where preserved. Clearly mark STALE when freshness threshold is exceeded. Never present an old frame as live.

## 14. DETERMINISTIC VALIDATOR
No model-generated action executes directly. Validate scope, target, operation type, evidence prerequisites, authority, destructive-operation policy, state, syntax and replay/duplication risk.

ABSOLUTE POWERSHELL RULE: generated PowerShell executed by SNAIL must contain NO else statement. Detect/tokenize before execution. If an else token exists, reject the entire script before any part executes and log VALIDATION_REJECTED_NO_ELSE_POLICY. Regeneration must use guard clauses, early returns, independent if blocks, functions, etc.

## 15. STEWARD DASHBOARD
Extend, do not replace, the current Steward dashboard. Use VISUAL_BASELINE and CURRENT_STEWARD_SNAPSHOT/dashboard as the baseline. Preserve campaign/infrastructure/Octo2 worker/current operation/recent events information.

Add SNAIL state, current/last event, current task, hypothesis, evidence under consideration, pending operation, next proposed action, checkpoint and worker recovery/wait state.

Controls required: PAUSE, STOP, RESUME, INQUIRY, SNAPSHOT, UPDATE TASK, UPDATE DIRECTION, PHYSICAL WORK COMPLETE, ABORT.

UPDATE TASK changes the immediate bounded objective. UPDATE DIRECTION changes higher-level guidance/constraints without erasing history. Every Steward command becomes an append-only event.

## 16. SNAPSHOT / SECOND SET OF EYES
Extend Snapshot so the ZIP contains REVIEW_PACKET.md generated from durable state/evidence: campaign/phase/task/objective/SNAIL state/current and last event/Octo2 state and boot ID/pending operation/recent significant events/verified facts/hypotheses/contradictions/changes since previous snapshot/evidence refs/next proposed action/reason for review. Include raw supporting artifacts.

## 17. ESCALATION
Configurable automatic PAUSE/escalation for repeated identical failure, contradictory evidence, impossible state, unknown target state, lost observation/control channel, repeated validator rejection, low confidence, reasoning without measurable progress, destructive operation outside authority, stock BIOS recovery request, recovery timeout, worker readiness failure or evidence/state corruption.

## 18. CAMPAIGN CONFIGURATION
Separate generic SNAIL engine behavior from campaign-specific configuration (target, worker, adapters, standing authority, prohibited operations, evidence requirements, thresholds/timeouts/retries). Initial campaign is Octo1 Multi-P100 BIOS. Future campaign is Octo2 Reboot Root Cause. Do not hard-code BIOS assumptions into the generic engine.

## 19. BIOS CAMPAIGN INHERITANCE
Do not restart the engineering investigation. Inherit the supplied campaign knowledge about the P100 population boundary, prior high-MMIO behavior, documented recovery path and eventual multi-P100 objective. The first post-qualification production BIOS step is C1 PLANNING, not autonomous flashing.

## 20. INSTALL / OPERATE
Deliver install/start/stop/status/test operation suitable for normal use without multiple manually maintained terminals. Document dependencies, ports, paths, config, logs, state, evidence, events, snapshots and recovery. Back up existing production campaign components before modification.

## 21. TESTING
Actually run hardware-independent tests for persistence, append integrity, response schema, malformed-response rejection, validator, PowerShell else rejection, checkpoint/process restart recovery, pause/stop/resume/inquiry/task update/direction update/snapshot, stale latest.jpg, evidence-frame preservation, worker unreachability/reboot/PID replacement and duplicate-action prevention. Do not claim PASS for tests not run.

## 22. MANDATORY RECOVERY QUALIFICATION
Run a harmless multi-event qualification: start from durable state; call 80B from evidence packet; validate/execute/verify a harmless operation; checkpoint; interrupt or deterministically simulate worker loss; prove WAITING_FOR_WORKER and intact campaign position; restore worker; rebuild context from disk; resume without duplicate state change; finish; generate Snapshot. PASS requires no conversational-memory dependency.

## 23. HARDWARE BOUNDARY
Where safe qualification would require physical manipulation or BIOS mutation, implement the production path and deterministic qualification test, then mark HARDWARE-UNQUALIFIED. Do not fabricate a pass and do not begin autonomous C1 mutation merely to qualify SNAIL.

## 24. ACCEPTANCE BOUNDARY
Final allowed status: SNAIL v1.0 — QUALIFIED FOR OCTO1 BIOS CAMPAIGN PLANNING.
Then SNAIL may generate a C1 planning proposal, Snapshot it, and wait for Steward/external review. Do not autonomously cross into C1 mutation.

## 25. FINAL REPORT
Return one concise implementation report: BUILT, REUSED, MODIFIED, MIGRATED, TESTED (actual results), HARDWARE-UNQUALIFIED, CURRENT SNAIL STATE, exact START/STOP commands, DASHBOARD address/path, EVIDENCE locations, and NEXT AUTHORIZED STEP. The next authorized step must be no further than generating the C1 BIOS planning proposal for review.
