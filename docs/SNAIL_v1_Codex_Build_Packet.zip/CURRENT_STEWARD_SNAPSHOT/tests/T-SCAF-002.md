# T-SCAF-002 — OCTO2 Reboot and 80B Recovery Observation

## Goal

Determine whether the DEV-side campaign monitor survives an actual OCTO2 outage
and correctly observes recovery of both the host and the Qwen3-Next 80B worker.

## Trigger

Unplanned / spontaneous OCTO2 reboot during campaign scaffolding.

No reboot was intentionally commanded as part of this test.

## Prior Known Boot

Boot ID:
0557fb2e-0286-422f-b270-300795631ef1

80B PID before reboot:
757

Prior worker state:
80B_READY

## Observed Timeline

### 20:57:24 EDT

Campaign monitor reported:

OCTO2_UNREACHABLE

Additional unreachable samples followed at approximately 10-second intervals.

### New Boot

New boot ID:

45093b9d-0398-4e1d-a523-07b1513f750e

This independently confirms an OCTO2 reboot occurred.

### 20:58:19 EDT

systemd started:

llama-server.service

New llama-server PID:

755

### 20:58:23 EDT

llama-server began loading:

Qwen3-Next-80B-A3B-Instruct-Q4_K_M.gguf

### 20:58:27 EDT

Campaign monitor observed the recovered host and classified the worker:

80B_NOT_READY

At this point:

- SSH worked
- the new boot ID was visible
- llama-server PID 755 existed
- inference API was not yet ready

### 21:04:18 EDT

llama-server journal reported:

- model loaded
- listening on 0.0.0.0:8080

Observed service-start-to-listen time:

approximately 5 minutes 59 seconds

Observed model-load-start-to-listen time:

approximately 5 minutes 55 seconds

### 21:04:25 EDT

Campaign monitor independently transitioned:

80B_NOT_READY -> 80B_READY

### 21:07:29 EDT

Monitor remained operational.

State:

80B_READY

Boot ID:

45093b9d-0398-4e1d-a523-07b1513f750e

PID:

755

API ready:

true

## Result

PASS

The DEV-side campaign monitor survived a real OCTO2 outage and continued
operating through:

1. host loss
2. OCTO2 reboot
3. SSH recovery
4. automatic llama-server service startup
5. extended 80B model loading
6. API recovery
7. return to 80B_READY

No Steward intervention was required for OCTO2 recovery.

## Defect Discovered

The monitor did NOT emit an explicit `octo2_boot_changed` event.

Cause:

The implementation compared the current boot ID only with the immediately
previous sample. During the outage, unreachable samples contained an empty boot
ID. The old boot identity was therefore lost before the new boot became visible.

Required correction:

Maintain a persistent `last_known_boot_id` independent of the immediately
previous health sample.

## Important Interpretation

`80B_NOT_READY` during this event did not mean that llama-server had failed.

PID 755 existed while the 80B model was still loading.

The campaign must distinguish at least:

- OCTO2_UNREACHABLE
- OCTO2_UP_MODEL_PROCESS_DOWN
- OCTO2_UP_80B_LOADING
- 80B_READY

## Timeout Evidence

One observed 80B cold start required approximately six minutes.

This is an observed data point, not yet a universal startup-time specification.

A temporary campaign threshold of 8 minutes is reasonable for initial
qualification, but it must remain configurable and should be revised as more
cold-start samples are collected.

## Status

PASS

TEST_RESULT: PASS
