"""Riverview Hermes bridge for the OctoMiner BIOS campaign PiKVM HID adapter."""

from __future__ import annotations

import json
import subprocess
from typing import Any


ADAPTER = r"T:\OctoMiner_BIOS_Campaign\repo\controller\Send-PiKVMKeys.ps1"


_TEXT_SCHEMA = {
    "name": "octominer_hid_type",
    "description": (
        "Type text on OCTO1 through the campaign's proven PiKVM physical HID "
        "adapter. Optionally press Enter after the text."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "Literal text to type on OCTO1."
            },
            "enter": {
                "type": "boolean",
                "description": "Press Enter after typing the text."
            }
        },
        "required": ["text"],
        "additionalProperties": False
    }
}


_KEY_SCHEMA = {
    "name": "octominer_hid_key",
    "description": (
        "Send one keyboard key to OCTO1 through the campaign's proven "
        "PiKVM physical HID adapter."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "key": {
                "type": "string",
                "description": "PiKVM/KVMD keyboard key name, for example Enter."
            }
        },
        "required": ["key"],
        "additionalProperties": False
    }
}


def _run_adapter(arguments: list[str]) -> str:
    command = [
        "pwsh.exe",
        "-NoProfile",
        "-File",
        ADAPTER,
        *arguments,
    ]

    proc = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=60,
    )

    result = {
        "ok": proc.returncode == 0,
        "returncode": proc.returncode,
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "adapter": ADAPTER,
    }

    if proc.returncode != 0:
        raise RuntimeError(json.dumps(result, ensure_ascii=False))

    return json.dumps(result, ensure_ascii=False)


def _handle_type(args: dict[str, Any], **_: Any) -> str:
    command = ["-Text", str(args["text"])]

    if bool(args.get("enter", False)):
        command.append("-Enter")

    return _run_adapter(command)


def _handle_key(args: dict[str, Any], **_: Any) -> str:
    return _run_adapter(["-Key", str(args["key"])])


def register(ctx) -> None:
    ctx.register_tool(
        name="octominer_hid_type",
        toolset="riverview",
        schema=_TEXT_SCHEMA,
        handler=_handle_type,
        description="Type text on OCTO1 through the proven PiKVM HID adapter.",
    )

    ctx.register_tool(
        name="octominer_hid_key",
        toolset="riverview",
        schema=_KEY_SCHEMA,
        handler=_handle_key,
        description="Send one physical keyboard key to OCTO1 through PiKVM.",
    )
