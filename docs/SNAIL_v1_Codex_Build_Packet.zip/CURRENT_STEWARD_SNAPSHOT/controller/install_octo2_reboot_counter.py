from pathlib import Path
import json
import shutil
import py_compile

ROOT = Path(r"T:\OctoMiner_BIOS_Campaign")
REPO = ROOT / "repo"
RUNTIME = ROOT / "workspace" / "campaign-runtime"

MONITOR = REPO / "controller" / "octo2_monitor_v2.py"
SERVER = REPO / "dashboard" / "steward_server.py"
HTML = REPO / "dashboard" / "index.html"
COUNTER = RUNTIME / "octo2-reboot-count.json"

# ----------------------------------------------------------
# BACKUPS
# ----------------------------------------------------------

for path in (MONITOR, SERVER, HTML):
    backup = path.with_name(path.name + ".before-octo2-reboots")
    shutil.copy2(path, backup)

# ----------------------------------------------------------
# PERSISTENT BASELINE
# ----------------------------------------------------------

if not COUNTER.exists():
    counter = {
        "count": 1,
        "prior_history_known": True,
        "baseline_note": (
            "Count begins with BIOS campaign instrumentation. "
            "OCTO2 had known spontaneous reboots before counting began."
        ),
        "last_boot_id": "45093b9d-0398-4e1d-a523-07b1513f750e"
    }

    COUNTER.write_text(
        json.dumps(counter, indent=2),
        encoding="utf-8"
    )

# ----------------------------------------------------------
# MONITOR V2
# ----------------------------------------------------------

m = MONITOR.read_text(encoding="utf-8")

if "REBOOT_COUNTER =" not in m:
    needle = 'TELEMETRY = DATA / "octo2-telemetry-v2.csv"'

    if needle not in m:
        raise RuntimeError("MONITOR TELEMETRY CONSTANT NOT FOUND")

    m = m.replace(
        needle,
        needle + '\nREBOOT_COUNTER = DATA / "octo2-reboot-count.json"',
        1
    )

if "def increment_reboot_counter(" not in m:
    needle = "\nprevious = None"

    if needle not in m:
        raise RuntimeError("MONITOR LOOP MARKER NOT FOUND")

    helper = r'''

def increment_reboot_counter(old_boot_id, new_boot_id):
    data = {
        "count": 0,
        "prior_history_known": True,
        "last_boot_id": old_boot_id,
    }

    if REBOOT_COUNTER.exists():
        try:
            data = json.loads(
                REBOOT_COUNTER.read_text(encoding="utf-8")
            )
        except Exception:
            pass

    # Prevent duplicate counting of the same boot.
    if data.get("last_boot_id") == new_boot_id:
        return

    data["count"] = int(data.get("count", 0)) + 1
    data["prior_history_known"] = True
    data["last_boot_id"] = new_boot_id
    data["previous_boot_id"] = old_boot_id
    data["last_reboot_observed_at"] = now_iso()

    REBOOT_COUNTER.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8"
    )

'''

    m = m.replace(
        needle,
        helper + needle,
        1
    )

call_signature = """            increment_reboot_counter(
                last_known_boot_id,
                current["boot_id"],
            )"""

if call_signature not in m:
    event_block = """            event(
                "octo2_boot_changed",
                old_boot_id=last_known_boot_id,
                new_boot_id=current["boot_id"],
            )"""

    if event_block not in m:
        raise RuntimeError("BOOT CHANGE EVENT BLOCK NOT FOUND")

    m = m.replace(
        event_block,
        event_block + "\n" + call_signature,
        1
    )

MONITOR.write_text(m, encoding="utf-8")

# ----------------------------------------------------------
# STEWARD DASHBOARD SERVER
# ----------------------------------------------------------

s = SERVER.read_text(encoding="utf-8")

if '"octo2_reboots": reboot_data' not in s:
    needle = "    counts = test_counts()\n"

    if needle not in s:
        raise RuntimeError("SERVER TEST COUNT MARKER NOT FOUND")

    addition = """
    reboot_data = read_json(
        RUNTIME / "octo2-reboot-count.json",
        {
            "count": 0,
            "prior_history_known": True
        }
    )
"""

    s = s.replace(
        needle,
        needle + addition,
        1
    )

    needle = '        "hard_resets": 0,\n'

    if needle not in s:
        raise RuntimeError("SERVER HARD RESET MARKER NOT FOUND")

    s = s.replace(
        needle,
        needle + '        "octo2_reboots": reboot_data,\n',
        1
    )

if '"runtime/octo2-reboot-count.json"' not in s:
    needle = '''    add_file(
        "runtime/octo2-telemetry-v2.csv",
        RUNTIME / "octo2-telemetry-v2.csv"
    )'''

    if needle not in s:
        raise RuntimeError("SNAPSHOT TELEMETRY MARKER NOT FOUND")

    addition = '''
    add_file(
        "runtime/octo2-reboot-count.json",
        RUNTIME / "octo2-reboot-count.json"
    )'''

    s = s.replace(
        needle,
        needle + addition,
        1
    )

SERVER.write_text(s, encoding="utf-8")

# ----------------------------------------------------------
# STEWARD HTML
# ----------------------------------------------------------

h = HTML.read_text(encoding="utf-8")

if 'id="octoreboots"' not in h:
    needle = '''<div class="card">
<div class="label">Hard Resets</div>
<div class="value" id="hardresets">—</div>
</div>'''

    if needle not in h:
        raise RuntimeError("HARD RESET CARD NOT FOUND")

    addition = '''

<div class="card">
<div class="label">OCTO2 Reboots</div>
<div class="value" id="octoreboots">—</div>
<div class="small">* known reboots occurred before counting began</div>
</div>'''

    h = h.replace(
        needle,
        needle + addition,
        1
    )

if 'const rebootData = d.octo2_reboots' not in h:
    needle = '''        document.getElementById("hardresets").textContent =
            d.hard_resets;
'''

    if needle not in h:
        raise RuntimeError("HARD RESET JAVASCRIPT NOT FOUND")

    addition = '''
        const rebootData = d.octo2_reboots || {};
        const rebootCount = rebootData.count || 0;
        const rebootSuffix =
            rebootData.prior_history_known ? "*" : "";

        document.getElementById("octoreboots").textContent =
            rebootCount + rebootSuffix;
'''

    h = h.replace(
        needle,
        needle + addition,
        1
    )

HTML.write_text(h, encoding="utf-8")

# ----------------------------------------------------------
# STATIC QUALIFICATION
# ----------------------------------------------------------

py_compile.compile(str(MONITOR), doraise=True)
py_compile.compile(str(SERVER), doraise=True)

counter = json.loads(COUNTER.read_text(encoding="utf-8"))

monitor_text = MONITOR.read_text(encoding="utf-8")
server_text = SERVER.read_text(encoding="utf-8")
html_text = HTML.read_text(encoding="utf-8")

checks = {
    "COUNTER_FILE": COUNTER.exists(),
    "BASELINE_ONE": counter.get("count") == 1,
    "ASTERISK_HISTORY":
        counter.get("prior_history_known") is True,
    "MONITOR_COMPILE": True,
    "SERVER_COMPILE": True,
    "MONITOR_INCREMENT":
        "increment_reboot_counter(" in monitor_text,
    "MONITOR_BOOT_HOOK":
        call_signature in monitor_text,
    "SERVER_API":
        '"octo2_reboots": reboot_data' in server_text,
    "SNAPSHOT_INCLUDES_COUNTER":
        '"runtime/octo2-reboot-count.json"' in server_text,
    "DASHBOARD_CARD":
        'id="octoreboots"' in html_text,
    "DASHBOARD_JS":
        "const rebootData = d.octo2_reboots" in html_text,
}

for name, passed in checks.items():
    print(f"{name}={'PASS' if passed else 'FAIL'}")

print()
print("COUNTER_STATE:")
print(json.dumps(counter, indent=2))
print()

if not all(checks.values()):
    raise SystemExit(1)

print("BUILD=PASS")
