TEST_RESULT: PASS

# T-SCAF-004 — Five-Node Infrastructure Health Qualification

## Goal

Prove that the Steward dashboard can report live management-path health for all
five systems involved in the OctoMiner BIOS campaign without modifying or
restarting any remote machine.

## Qualified Nodes

### DEV

Role:
Campaign controller and Steward dashboard host.

Observed state:

- READY
- GREEN
- Steward controller running

### OCTO1

Address:

192.168.1.160

SSH alias:

octo1

Observed:

- ICMP reachable
- TCP/22 reachable
- SSH authentication successful
- hostname: OCTOMINER1

Steward result:

- READY
- GREEN
- SSH/22 reachable

### OCTO2

Address:

192.168.1.162

Health authority:

octo2_monitor_v2.py

Observed:

- SSH reachable
- Qwen3-Next 80B API ready
- state: 80B_READY
- reboot counter: 2
- reboot count authoritative from controlled synchronization event

Steward result:

- READY
- GREEN
- SSH + 80B API ready

### PiKVM

Address:

192.168.1.169

SSH alias:

pikvm

Observed:

- ICMP reachable
- TCP/22 reachable
- TCP/80 reachable
- TCP/443 reachable
- SSH authentication successful
- hostname: pikvm

Steward result:

- READY
- GREEN
- SSH/22 + HTTP/80 + HTTPS/443 reachable

### Video-KVM Pi

Address:

192.168.1.101

SSH alias:

video1

Observed:

- ICMP reachable
- TCP/22 reachable
- SSH authentication successful
- hostname: raspberrypi

Steward result:

- READY
- GREEN
- SSH/22 reachable

## Probe Design

Steward uses bounded TCP probes implemented with socket.create_connection().

Probe timeout:

0.75 seconds

Port 2222 is not part of the management-health contract. Its earlier inclusion
was caused by a dictation error.

OCTO2 remains governed by its dedicated monitor rather than generic TCP
reachability because its operational states include model loading and API
readiness.

## Performance

Measured /api/status response during qualification:

127 ms

## Process Integrity

OCTO2 Monitor V2 remained:

PID 43172

No OCTO2 reboot occurred during this qualification.

No remote-machine configuration was changed.

## Result

PASS

All five campaign systems were represented by live health information:

DEV — GREEN
OCTO1 — GREEN
OCTO2 — GREEN
PiKVM — GREEN
Video-KVM Pi — GREEN

## Architectural Follow-Up

The bounded synchronous probes are acceptable for campaign qualification.

A future improvement is to move generic infrastructure probing into a
persistent monitor/cache so dashboard HTTP requests never directly depend on
network-probe latency.

## Status

PASS
