# SNAIL v1.0 — BUILD PACKET MANIFEST

## READ THIS FIRST
This packet was curated from the uploaded `standalone(2).zip` plus the current Steward Snapshot captured 2026-10-04. It intentionally excludes the overwhelming majority of Riverview Standalone.

**Do not perform repository-wide Riverview discovery.** Use this packet as the bounded implementation context. If an exact dependency is missing, identify it specifically rather than recursively exploring Riverview.

## Precedence / reading order
1. `SNAIL_V1_CODEX_SPEC.md` — build contract.
2. `CURRENT_STEWARD_SNAPSHOT/` — current live campaign implementation/evidence baseline supplied to the build.
3. `REFERENCE_RIVERVIEW/docs/operations/octominer/campaign/START_HERE.md`
4. `.../APPROVED_PROPOSAL.md`
5. `.../CAMPAIGN_STATE.md` — historical/current-state file that MUST be reconciled with later proven evidence; do not erase history.
6. `.../PROVEN_FACTS.md`, `PROVEN_NOT_WORKING.md`, `LESSONS_LEARNED.md`, `OPEN_QUESTIONS.md`.
7. `.../REGROUND_PACKET.md` and `REGROUND_CONTRACT.md` as consolidated historical campaign context.
8. Selected implementation/reference source under `REFERENCE_RIVERVIEW/src`, `.hermes`, `tools`, and `tests`.
9. `VISUAL_BASELINE/` — current operator UI visual references.

## Current Steward Snapshot contents
The supplied Snapshot contains the current dashboard HTML/server, steward state, Octo2 current state, events-v2 JSONL, Octo2 telemetry, reboot count, campaign docs, T-SCAF-001..005 records, build_reground_packet, Octo2 monitor v1/v2 and video1_relay.py. These are particularly important because the broader standalone tree does not expose video1 implementation by filename.

## Why this is curated
The source standalone archive is ~357 MB compressed and contains tens of thousands of entries, including `.git`, `.venv`, caches, browser profiles, runtime histories, backup generations and unrelated Riverview systems. Those are intentionally excluded.

## Explicit exclusions
Do not request or explore `.git`, `.venv`, `__pycache__`, pytest/browser caches, UI acceptance browser profiles, old `.pre-*`/`.before-*` generations, unrelated Grace/Riverview subsystems, unrelated model experiments, model weights, large historical runtime logs, or archived development state unless a specific implementation dependency proves necessary.

## Important architecture distinction
**Codex builds SNAIL and then exits normal operation.** Codex is not a SNAIL runtime component.

Normal runtime is DEV persistent controller/evidence/Steward + Octo2 80B reasoning worker + DEV 3060 Ti vision + PiKVM HID + video1 observation + Octo1 target.

## Campaign freeze warning
The older `CAMPAIGN_STATE.md` does not by itself represent all later proven T-SCAF-005/video/HID/vision evidence. Reconcile it by creating the SNAIL handoff checkpoint specified in the build contract. Preserve the older checkpoint as history.
