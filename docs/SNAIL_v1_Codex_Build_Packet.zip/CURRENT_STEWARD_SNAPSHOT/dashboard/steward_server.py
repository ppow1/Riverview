import re
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json
import os
import socket
import io
import zipfile
import subprocess
from datetime import datetime

ROOT = Path(r"T:\OctoMiner_BIOS_Campaign")
REPO = ROOT / "repo"
RUNTIME = ROOT / "workspace" / "campaign-runtime"
DASH = REPO / "dashboard"

HOST = "127.0.0.1"
PORT = 8785
def read_text(path, default=""):
    try:
        return Path(path).read_text(encoding="utf-8")
    except Exception:
        return default


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def tail_lines(path, count=40):
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
        return lines[-count:]
    except Exception:
        return []


def test_counts():
    tests = list((REPO / "tests").glob("*.md"))
    passed = 0
    failed = 0
    pending = 0
    aborted = 0
    unmarked = 0

    result_pattern = re.compile(
        r"(?m)^TEST_RESULT:\s*(PASS|FAIL|PENDING|ABORTED)\s*$"
    )

    for path in tests:
        content = path.read_text(encoding="utf-8", errors="replace")
        matches = result_pattern.findall(content)

        if len(matches) != 1:
            unmarked += 1
            continue

        result = matches[0]

        if result == "PASS":
            passed += 1
        elif result == "FAIL":
            failed += 1
        elif result == "PENDING":
            pending += 1
        elif result == "ABORTED":
            aborted += 1

    return {
        "total": len(tests),
        "passed": passed,
        "failed": failed,
        "pending": pending,
        "aborted": aborted,
        "unmarked": unmarked,
        "completed": passed + failed + aborted,
    }

def tcp_probe(host, port, timeout=0.75):
    """Bounded TCP connectivity probe. Never allow dashboard health to hang."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, TimeoutError):
        return False


def infrastructure_health(octo):
    # Management-path contracts qualified 2026-10-01.
    #
    # OCTO1:
    #   192.168.1.160, SSH/22
    #
    # PiKVM:
    #   192.168.1.169, SSH/22 + HTTP/80 + HTTPS/443
    #
    # Video-KVM Pi:
    #   192.168.1.101, SSH/22
    #
    # OCTO2 remains authoritative from octo2_monitor_v2.py.

    octo1_ssh = tcp_probe("192.168.1.160", 22)

    pikvm_ssh = tcp_probe("192.168.1.169", 22)
    pikvm_http = tcp_probe("192.168.1.169", 80)
    pikvm_https = tcp_probe("192.168.1.169", 443)

    video_ssh = tcp_probe("192.168.1.101", 22)

    if octo1_ssh:
        octo1 = {
            "name": "OCTO1",
            "status": "READY",
            "color": "green",
            "detail": "SSH/22 reachable",
        }
    else:
        octo1 = {
            "name": "OCTO1",
            "status": "DOWN",
            "color": "red",
            "detail": "SSH/22 unavailable",
        }

    pikvm_services = sum((pikvm_ssh, pikvm_http, pikvm_https))

    if pikvm_services == 3:
        pikvm = {
            "name": "PiKVM",
            "status": "READY",
            "color": "green",
            "detail": "SSH/22 + HTTP/80 + HTTPS/443 reachable",
        }
    elif pikvm_services > 0:
        available = []
        if pikvm_ssh:
            available.append("SSH/22")
        if pikvm_http:
            available.append("HTTP/80")
        if pikvm_https:
            available.append("HTTPS/443")

        pikvm = {
            "name": "PiKVM",
            "status": "DEGRADED",
            "color": "yellow",
            "detail": "partial: " + " + ".join(available),
        }
    else:
        pikvm = {
            "name": "PiKVM",
            "status": "DOWN",
            "color": "red",
            "detail": "management services unavailable",
        }

    if video_ssh:
        videokvm = {
            "name": "Video-KVM Pi",
            "status": "READY",
            "color": "green",
            "detail": "SSH/22 reachable",
        }
    else:
        videokvm = {
            "name": "Video-KVM Pi",
            "status": "DOWN",
            "color": "red",
            "detail": "SSH/22 unavailable",
        }

    state = (octo or {}).get("state", "UNKNOWN")

    if state == "80B_READY":
        octo2 = {
            "name": "OCTO2",
            "status": "READY",
            "color": "green",
            "detail": "SSH + 80B API ready",
        }
    elif state in ("80B_LOADING", "OCTO2_UP_80B_LOADING", "80B_NOT_READY"):
        octo2 = {
            "name": "OCTO2",
            "status": "LOADING",
            "color": "yellow",
            "detail": state,
        }
    else:
        octo2 = {
            "name": "OCTO2",
            "status": "DOWN",
            "color": "red",
            "detail": state,
        }

    return {
        "dev": {
            "name": "DEV",
            "status": "READY",
            "color": "green",
            "detail": "Steward controller running",
        },
        "octo1": octo1,
        "octo2": octo2,
        "pikvm": pikvm,
        "videokvm": videokvm,
    }

def snapshot():
    octo = read_json(RUNTIME / "octo2-current-v2.json")

    events = []
    for line in tail_lines(RUNTIME / "events-v2.jsonl", 30):
        try:
            events.append(json.loads(line))
        except Exception:
            events.append({"raw": line})

    counts = test_counts()

    reboot_data = read_json(
        RUNTIME / "octo2-reboot-count.json",
        {
            "count": 0,
            "prior_history_known": True
        }
    )

    return {
        "dashboard_time": datetime.now().astimezone().isoformat(timespec="seconds"),
        "campaign": {
            "name": "OctoMiner BIOS Campaign",
            "phase": "Campaign Infrastructure Qualification",
            "objective": "Establish autonomous test infrastructure before BIOS candidate execution",
            "status": "BUILDING",
        },
        "tests": counts,
        "bios_updates": 0,
        "software_resets": 0,
        "hard_resets": 0,
        "octo2_reboots": reboot_data,
        "steward_notifications": 0,
        "steward_wait_seconds": 0,
        "paused": False,
        "steward_needed": False,
        "current_operation": "Building Steward dashboard",
        "infrastructure": infrastructure_health(octo),
        "octo2": octo,
        "events": events,
    }


def build_snapshot_zip():
    stamp = datetime.now().astimezone()
    stamp_file = stamp.strftime("%Y%m%d-%H%M%S")
    status = snapshot()

    manifest = {
        "snapshot_type": "STEWARD_BIOS_CAMPAIGN",
        "created_at": stamp.isoformat(timespec="seconds"),
        "dashboard_url": f"http://{HOST}:{PORT}/",
        "purpose": (
            "Self-contained Steward diagnostic snapshot for ChatGPT review. "
            "Represents campaign/dashboard state when Snapshot was pressed."
        ),
        "campaign": status.get("campaign", {}),
        "current_operation": status.get("current_operation"),
        "octo2_state": status.get("octo2", {}),
        "tests": status.get("tests", {}),
    }

    files = {}

    def add_file(archive_name, source):
        source = Path(source)
        if source.exists() and source.is_file():
            try:
                files[archive_name] = source.read_bytes()
            except Exception as exc:
                files[archive_name + ".ERROR.txt"] = str(exc).encode("utf-8")

    files["manifest.json"] = json.dumps(
        manifest, indent=2
    ).encode("utf-8")

    files["steward_state.json"] = json.dumps(
        status, indent=2
    ).encode("utf-8")

    add_file("dashboard/index.html", DASH / "index.html")
    add_file("dashboard/steward_server.py", DASH / "steward_server.py")

    add_file(
        "runtime/octo2-current-v2.json",
        RUNTIME / "octo2-current-v2.json"
    )
    add_file(
        "runtime/events-v2.jsonl",
        RUNTIME / "events-v2.jsonl"
    )
    add_file(
        "runtime/octo2-telemetry-v2.csv",
        RUNTIME / "octo2-telemetry-v2.csv"
    )
    add_file(
        "runtime/octo2-reboot-count.json",
        RUNTIME / "octo2-reboot-count.json"
    )

    for name in [
        "CAMPAIGN_STATE.md",
        "PROVEN_FACTS.md",
        "PROVEN_NOT_WORKING.md",
        "LESSONS_LEARNED.md",
        "OPEN_QUESTIONS.md",
        "README.md",
    ]:
        add_file("campaign/" + name, REPO / name)

    tests_dir = REPO / "tests"
    if tests_dir.exists():
        for path in sorted(tests_dir.glob("*.md")):
            add_file("tests/" + path.name, path)

    controller_dir = REPO / "controller"
    if controller_dir.exists():
        for path in sorted(controller_dir.glob("*.py")):
            add_file("controller/" + path.name, path)

    try:
        git_status = subprocess.run(
            ["git", "-C", str(REPO), "status", "--short", "--branch"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        files["git/status.txt"] = (
            git_status.stdout + git_status.stderr
        ).encode("utf-8")

        git_sha = subprocess.run(
            ["git", "-C", str(REPO), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        files["git/commit.txt"] = (
            git_sha.stdout + git_sha.stderr
        ).encode("utf-8")
    except Exception as exc:
        files["git/ERROR.txt"] = str(exc).encode("utf-8")

    buffer = io.BytesIO()

    with zipfile.ZipFile(
        buffer,
        "w",
        compression=zipfile.ZIP_DEFLATED
    ) as z:
        for archive_name, data in files.items():
            z.writestr(archive_name, data)

    return (
        buffer.getvalue(),
        f"steward-snapshot-{stamp_file}.zip"
    )


class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/snapshot":
            body, filename = build_snapshot_zip()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="{filename}"'
            )
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if self.path == "/api/status":
            body = json.dumps(snapshot(), indent=2).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return super().do_GET()

    def log_message(self, fmt, *args):
        pass


os.chdir(DASH)

print(f"STEWARD dashboard: http://{HOST}:{PORT}", flush=True)

ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
