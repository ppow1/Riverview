# OctoMiner 1 Multi-P100 BIOS Campaign

## Campaign Goal
Develop and validate firmware capable of supporting 10+ Tesla P100 16GB GPUs
while retaining practical stock-equivalent boot behavior.

## Current Phase
PHASE 0 — Automation scaffolding and interface qualification.

## Current Hardware Validation Target
No expanded-P100 claim yet.

First physical boundary test after firmware qualification:
3 x Tesla P100 16GB.

## Campaign Rule
No experiment is complete without PRE, execution evidence, POST analysis,
and an explicit statement of what was learned.
