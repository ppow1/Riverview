# T-SCAF-005 — Closed-Loop KVM Proof

## Purpose

Prove one complete non-destructive automation loop:

PiKVM HID -> OCTO1 -> independent video1 observation.

This test qualifies the deterministic KVM control/observation path required
before BIOS candidate execution.

## Architecture Authority

The current REGROUND_PACKET.md is the required architecture authority for this
test.

Relevant roles:

- PiKVM: HID/control path to OCTO1.
- video1: independent HDMI/UVC observation path from OCTO1.
- octo1: target operating-system diagnostic path.
- Steward: human control/gating authority.

## Preconditions

1. Campaign reground gate PASS.
2. PiKVM reachable by SSH.
3. PiKVM KVMD HID API available.
4. video1 reachable by SSH.
5. Existing video1 capture stream remains running and MUST NOT be killed merely
   to obtain a second /dev/video0 handle.
6. OCTO1 reachable by SSH.
7. OCTO1 boot ID recorded before execution.
8. Steward can see the authoritative video1 console feed.
9. Before any marker text is sent, the visible OCTO1 console MUST be confirmed
   to be in a harmless text-entry state where unsubmitted text cannot trigger
   an action merely by being typed.

## Test Marker

T-SCAF-005-KVM-PROOF

## Execution Contract

### Step 1 — Baseline

Record:

- OCTO1 boot ID.
- OCTO1 uptime.
- current foreground console.
- PiKVM HID availability.
- video1 capture-process PID/state.

PASS requires all management paths to remain healthy.

### Step 2 — Establish Safe Visible Input State

Using observation through video1, establish that the visible OCTO1 console is
at a harmless text-entry location.

Do NOT proceed if the visible target is:

- BIOS/UEFI setup,
- bootloader command entry,
- password entry,
- destructive/recovery prompt,
- package/configuration prompt,
- an application where arbitrary typed text can invoke an action,
- or any state whose behavior is uncertain.

If safety cannot be established, result is INCONCLUSIVE and no HID marker is
sent.

### Step 3 — HID Action

Through the supported PiKVM KVMD HID API, type exactly:

T-SCAF-005-KVM-PROOF

Do NOT append Enter/Return.

No shell command is intentionally executed.

### Step 4 — Independent Observation

The authoritative observation source is video1.

PASS requires the exact marker:

T-SCAF-005-KVM-PROOF

to become visibly present on the OCTO1 console after the PiKVM HID action.

Observation through OCTO1 SSH alone is NOT sufficient to satisfy this step.

### Step 5 — Cleanup

After visual PASS, send Ctrl+U through the supported PiKVM HID interface only
if the established text-entry environment is known to interpret Ctrl+U as
harmless line clearing.

If that interpretation is not established, do not improvise cleanup. Stop and
record the visible state for Steward review.

### Step 6 — Target Health Verification

After the HID proof, independently verify through OCTO1 SSH:

- boot ID unchanged,
- SSH remains reachable,
- no reboot occurred.

## PASS Criteria

PASS only if all are true:

1. Safe visible text-entry state established before HID execution.
2. Marker entered through PiKVM HID.
3. No Enter/Return sent with marker.
4. Exact marker independently observed through video1.
5. OCTO1 remains reachable.
6. OCTO1 boot ID remains unchanged.
7. No unintended command or target action is observed.
8. Existing video1 capture stream remains operational.

## Failure Classification

- HID action fails -> FAIL.
- HID succeeds but marker cannot be independently observed -> FAIL.
- video1 unavailable or observation ambiguous -> INCONCLUSIVE.
- Safe text-entry state cannot be established -> INCONCLUSIVE.
- Unexpected target behavior -> HALT and STEWARD.
- OCTO1 reboot/boot-ID change -> HALT and STEWARD.

## Prohibitions

This test does NOT authorize:

- BIOS writes,
- BIOS configuration changes,
- reboot,
- reset,
- power cycle,
- Enter/Return after the test marker,
- PiKVM reboot,
- termination of the established video1 stream,
- USB mass-storage manipulation,
- stock recovery,
- unrelated remote configuration changes.

## Result

PENDING

## Execution Evidence — Step 3 / Step 4

Step 3:
- KVMD accepted POST /hid/print.
- Marker requested: T-SCAF-005-KVM-PROOF
- Enter/Return was not included.
- KVMD response: ok=true.
- CURL_EXIT=0.
- HID API action result: PASS at the API acceptance layer.

Step 4:
- Authoritative observation source: video1.
- video1 acquisition remained live as proven by advancing latest.jpg timestamps.
- Hermes observation of a fresh frame reported the marker absent with HIGH
  confidence.
- visible OCTO1 input line remained empty.

Current classification:
- Step 3 API acceptance: PASS.
- Step 4 independent visible observation: FAIL.
- T-SCAF-005 overall: FAIL pending failure analysis.
- Cleanup is NOT authorized.
- No Ctrl+U has been sent.
- No HID retry is authorized until the failure mechanism is understood.

Important distinction:
KVMD API acceptance proves that the control service accepted the request.
It does not prove that OCTO1 visibly received the resulting HID events.
