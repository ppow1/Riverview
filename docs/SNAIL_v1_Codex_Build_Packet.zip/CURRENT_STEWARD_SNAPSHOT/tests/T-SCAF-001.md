# T-SCAF-001 — OCTO2 80B Dependency Monitor Qualification

## Goal

Prove that the DEV-side BIOS campaign controller can independently determine
whether OCTO2 and its Qwen3-Next 80B reasoning worker are available.

## Expected Result

Every 10 seconds the monitor should record:

- OCTO2 SSH reachability
- Linux boot ID
- system uptime
- Qwen3-Next 80B llama-server PID
- port 8080 API readiness
- derived worker state

A healthy worker must report `80B_READY`.

## Initial Test

FAIL.

The first implementation returned `80B_PROCESS_DOWN` even though the previously
validated 80B service was believed to still be operating.

Observed output included two numeric values after `uptime=` and an empty PID.

## Root Cause

The remote command used `/proc/uptime` through a nested SSH/shell parsing
expression. `/proc/uptime` contains both uptime and aggregate idle time.

The command/parsing boundary did not produce the field layout expected by the
controller. The PID field was therefore parsed incorrectly and the monitor
generated a false `80B_PROCESS_DOWN` classification.

## Corrective Action

The monitor was rebuilt so that the remote side returns three simple lines:

1. boot ID
2. complete `/proc/uptime`
3. matching llama-server PID

Python performs the final field extraction locally.

## Retest

PASS.

Three consecutive observations:

- 2026-10-01T20:53:32-04:00 — `80B_READY`
  - uptime: 1278.27
  - PID: 757
  - boot: 0557fb2e-0286-422f-b270-300795631ef1

- 2026-10-01T20:53:42-04:00 — `80B_READY`
  - uptime: 1288.49
  - PID: 757
  - boot: 0557fb2e-0286-422f-b270-300795631ef1

- 2026-10-01T20:53:52-04:00 — `80B_READY`
  - uptime: 1298.70
  - PID: 757
  - boot: 0557fb2e-0286-422f-b270-300795631ef1

## Conclusion

The DEV-side OCTO2 dependency monitor is qualified for campaign use.

The failed samples remain part of the evidence history and must not be
interpreted as an actual OCTO2 or 80B outage.

## Lesson Learned

Prefer simple remote commands with local parsing across SSH boundaries.

For small generated controller files, deterministic complete-file generation is
preferred over complex PowerShell in-place patching with nested here-strings.

## Status

PASS

TEST_RESULT: PASS
